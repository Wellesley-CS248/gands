import pandas as pd
from datetime import datetime
import os

dining_hall = "Lulu"
meal = "Breakfast"
date = datetime.now
print(os.listdir())


