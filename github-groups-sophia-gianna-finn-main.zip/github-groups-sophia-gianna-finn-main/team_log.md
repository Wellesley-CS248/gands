Team Log
Week 1:

Joint work on one computer:
Tuesday, April 1st 6:15-9:15pm
Wednesday, April 2nd 9-11pm
Sophia: Streamlit tutorial 
Giana: 2 hours of work on final touches on code, streamlit tutorial

Week 2:
Meetings:
Saturday 5th, 7-9pm
Monday 7th, 3:30-4:30pm
Tuesday 8th, 2:30-6pm
Wednesday 9th, 8:30-9:30am
Joint work: lots of hours on brainstorming doc, logo/brand creation, app layout, important app elements, usability conversations, google slides, etc.
Sophia: Figma
Giana: ER diagramming

Week 3:
Meetings: Wednesday, 4:30 - 5:30 pm; Worked more on how to connect our sides of the project, discussed data
visualizations and pages
Joint Work:
Sophia:
Giana: Went to Johanna's office hours to map out backend of project,
